package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// TODO: Auto-generated Javadoc
/**
 * The Class PlataformaexamenesApplicationTests.
 */
@SpringBootTest
class PlataformaexamenesApplicationTests {

	/**
	 * Context loads.
	 */
	@Test
	void contextLoads() {
	}

}
